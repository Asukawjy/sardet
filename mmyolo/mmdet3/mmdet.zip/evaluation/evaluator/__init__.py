# Copyright (c) OpenMMLab. All rights reserved.
from .multi_datasets_evaluator import MultiDatasetsEvaluator

__all__ = ['MultiDatasetsEvaluator']
